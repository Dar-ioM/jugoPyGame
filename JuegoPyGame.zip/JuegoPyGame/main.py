import pygame
import sys

# Inicializar PyGame
pygame.init()

# Configuración de pantalla
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Primer Juego con PyGame")

# Colores
BLUE = (0, 0, 255)
RED = (255, 0, 0)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
DARK_BLUE = (0, 0, 139)

# Carga la imagen de fondo
background = pygame.image.load("imag.png")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

# Carga las imágenes del jugador y del enemigo
player_image = pygame.image.load("jugador.png")
player_image = pygame.transform.scale(player_image, (50, 50))  # Escalar la imagen al tamaño deseado

enemy_image = pygame.image.load("enemigo.png")
enemy_image = pygame.transform.scale(enemy_image, (50, 50))  # Escalar la imagen al tamaño deseado

# Fuentes
font = pygame.font.Font(pygame.font.match_font("comicsansms"), 74)
small_font = pygame.font.Font(pygame.font.match_font("comicsansms"), 36)

# Función para mostrar el menú
def show_menu():
    menu_running = True
    while menu_running:
        screen.blit(background, (0, 0))  # Dibuja el fondo

        # Texto del menú
        title_text = font.render("Menu Principal", True, YELLOW)
        start_text = small_font.render("Presiona ENTER para jugar", True, WHITE)
        quit_text = small_font.render("Presiona ESC para salir", True, WHITE)

        # Mostrar texto en la pantalla
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 3))
        screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2))
        screen.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 50))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # ENTER para jugar
                    menu_running = False
                if event.key == pygame.K_ESCAPE:  # ESC para salir
                    pygame.quit()
                    sys.exit()

# Función para mostrar pantalla de Game Over
def game_over():
    game_over_running = True
    while game_over_running:
        screen.fill(WHITE)  # Fondo blanco

        # Texto de Game Over
        over_text = font.render("GAME OVER", True, RED)
        retry_text = small_font.render("Presiona R para volver a jugar", True, DARK_BLUE)
        quit_text = small_font.render("Presiona ESC para salir", True, DARK_BLUE)

        # Mostrar texto en la pantalla
        screen.blit(over_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT // 3))
        screen.blit(retry_text, (WIDTH // 2 - retry_text.get_width() // 2, HEIGHT // 2))
        screen.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 50))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:  # R para reiniciar
                    game_over_running = False
                    main()
                if event.key == pygame.K_ESCAPE:  # ESC para salir
                    pygame.quit()
                    sys.exit()

# Función principal del juego
def main():
    clock = pygame.time.Clock()
    running = True

    # Configuración del jugador
    player_x, player_y = WIDTH // 2, HEIGHT - 50
    player_speed = 7

    # Configuración del enemigo
    enemy_x, enemy_y = 100, 100
    enemy_speed_x, enemy_speed_y = 5, 5

    # Llama al menú antes de iniciar el juego
    show_menu()

    # Bucle del juego
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Movimiento del jugador con teclas
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < WIDTH - 50:
            player_x += player_speed
        if keys[pygame.K_UP] and player_y > 0:
            player_y -= player_speed
        if keys[pygame.K_DOWN] and player_y < HEIGHT - 50:
            player_y += player_speed

        # Movimiento del enemigo
        enemy_x += enemy_speed_x
        enemy_y += enemy_speed_y

        # Rebote del enemigo en los bordes
        if enemy_x <= 0 or enemy_x >= WIDTH - 50:
            enemy_speed_x = -enemy_speed_x
        if enemy_y <= 0 or enemy_y >= HEIGHT - 50:
            enemy_speed_y = -enemy_speed_y

        # Comprobar colisión
        if (
            player_x < enemy_x + 50 and
            player_x + 50 > enemy_x and
            player_y < enemy_y + 50 and
            player_y + 50 > enemy_y
        ):
            game_over()

        # Dibujar en pantalla
        screen.blit(background, (0, 0))  # Dibuja el fondo
        screen.blit(player_image, (player_x, player_y))  # Dibuja el jugador
        screen.blit(enemy_image, (enemy_x, enemy_y))  # Dibuja el enemigo
        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()
